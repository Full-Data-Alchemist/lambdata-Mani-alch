
"""lambdata - a collection of Data Science Functions"""

import setuptools 


REQUIRED = [
  "numpy",
  "pandas",
  "Sklearn",
  "shap"
  "shapley"
]

with open("README.md", "r") as fh:
  LONG_DESCRIPTION = fh.read()

setuptools.setup(
  name="Lambdata-ManI-Alch",
  version="0.0.3",
  author="Full-Data-Alchemist",
  description="A collection of data science functions",
  long_description=LONG_DESCRIPTION,
  long_description_content="text/markdown",
  url='https://github.com/Full-Data-Alchemist/lambdata-Mani-alch',
  packages=setuptools.find_packages(),
  python_requires=">=3.6",
  install_requires=REQUIRED,
  classifiers=[
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent"
  ]
)